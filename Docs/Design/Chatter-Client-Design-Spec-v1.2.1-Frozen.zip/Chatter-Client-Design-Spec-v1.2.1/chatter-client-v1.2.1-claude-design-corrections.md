# Chatter Client Design Spec v1.2.1 — Final Architecture Alignment Corrections

## Purpose

Apply a **small final correction pass** to the current **Chatter Client Design Spec v1.2**.

This is **not a redesign**.

Do not restart product exploration.

Do not change the visual direction, information architecture, shared shell, provider extension model, or existing UX flows unless a correction below directly requires it.

The goal is to produce a **v1.2.1** that resolves a few remaining architecture/specification inconsistencies before the design is frozen.

---

# 1. Preserve the Current Design

Keep the following stable unless strictly necessary:

- visual language;
- layouts;
- sidebar/navigation structure;
- conversation timeline;
- composer direction;
- thread panel;
- diagnostics panel;
- capability inspector;
- extension-slot architecture;
- responsive strategy;
- accessibility strategy;
- WhatsApp-first / Slack-ready approach;
- provider-specific extension mechanism;
- application-state ownership model;
- browser/server boundary;
- contextual capability resolution;
- typed capability descriptors.

This pass should be primarily editorial and architectural.

---

# 2. Remove Implicit Offline / Reconnect Message Queueing

The current spec contains lifecycle states where message sending is described as:

```text
starting      → queued
reconnecting  → queued / send disabled
```

This implicitly introduces an offline message queue.

That behavior is **not currently part of the approved Chatter architecture**.

It also creates ambiguity between:

```text
queued
```

and:

```text
send disabled
```

Update the design to use the simpler approved behavior:

```text
starting      → cannot send
connected     → can send
reconnecting  → cannot send
degraded      → capability/context dependent
failed        → cannot send
stopped       → cannot send
```

The UI should explain why sending is unavailable when relevant.

Do not assume that a message composed during reconnect will automatically be sent later.

If offline/reconnect queueing is desired in the future, it should be treated as a separate feature with its own specification.

Draft text may remain in the composer/application state, but that is different from queuing a message for automatic transmission.

---

# 3. Do Not Silently Split Multi-Attachment Sends

The current design includes behavior equivalent to:

> If the provider cannot send multiple attachments in a single message, send them as sequential messages.

This violates an important Chatter design principle:

> Unsupported semantics must not silently degrade into different semantics.

Example:

```text
User intent:
1 message
+ 3 attachments
```

must not silently become:

```text
3 separate messages
```

Update the design rule to:

```text
If the current provider/context cannot represent the requested
attachment grouping, explain the limitation before send.
```

The UI may explicitly offer:

```text
Send as 3 separate messages
```

but this must be a clear user decision.

Do not perform the transformation automatically.

The example client should help the user recover from an unsupported composition without pretending the original operation succeeded unchanged.

---

# 4. Reframe G8 — Reply Target Availability

The current design identifies a gap around distinguishing:

```text
reply target not currently loaded
```

from:

```text
reply target deleted/unavailable
```

Do **not** introduce a new universal availability field on `MessageRef` merely to solve this UX.

Keep message references small.

Reframe this gap around **message lookup/history capability behavior**.

Preferred conceptual flow:

```text
replyTo MessageRef exists
        ↓
target not in local application store
        ↓
if a provider/message-history lookup capability exists:
    attempt lookup
        ↓
found → load/render target
not found/unavailable → show unavailable state
```

If no lookup/history capability exists, the client may show a neutral fallback such as:

```text
Referenced message is not available locally
```

without inventing provider truth.

Update G8 accordingly.

The gap is about optional retrieval/lookup semantics, not a required property of every `MessageRef`.

---

# 5. Reframe G7 — Error Metadata, Not Error Taxonomy

Chatter already has an approved normalized error model with categories such as:

```text
AuthenticationError
PermissionError
RateLimitError
InvalidRequestError
UnsupportedCapabilityError
MessageDeliveryError
ProviderUnavailableError
ConfigurationError
UnknownProviderAccountError
DuplicateProviderAccountError
```

Therefore, do not describe G7 as though Chatter lacks normalized errors entirely.

Reframe the remaining need as:

# Normalized Error Metadata

The example client may need additional normalized metadata to decide how to present and recover from an error.

Potential examples:

```text
retryable
retryAfterMs
correlationId
provider/account context
operation context
```

Do not prescribe exact fields unless needed by the UX.

The design should state the user-facing requirement and leave the final public API shape to Chatter feature specification.

Raw provider errors remain diagnostics-only and should not be the primary UI error contract.

---

# 6. Refine Message Status Progression Rules

The current design contains a rule similar to:

> The message row keeps the furthest-advanced state it has seen and status never regresses.

This should not become a universal Chatter status ordering assumption.

Some provider-specific status models, such as WhatsApp delivery/read state, have meaningful ordered progression.

Others may not.

Update the rule to:

> For provider status models that define an ordered progression, the client must not visually regress a message solely because status events arrive out of order.

Example:

```text
sent
→ delivered
→ read
```

If a delayed `delivered` event arrives after `read`, the UI should remain `read`.

Do not define a universal ordering such as:

```text
pending < sent < delivered < read < failed
```

because error/failure states may not fit a simple monotonic progression.

The relevant provider-specific Chatter API should define whether a status model has ordered progression.

---

# 7. Correct the Statement About Chatter Core Changes

The current specification contains language equivalent to:

> None of the identified gaps changes Chatter's core model.

That statement is no longer accurate.

Several approved changes refine public/core contracts, including:

- contextual capability resolution;
- typed capability descriptors;
- `receivedAt` / ordering semantics;
- per-account lifecycle/health.

Replace the statement with something equivalent to:

> Some of these gaps refine previously planned Chatter public contracts, but none require bypassing Chatter or violating its architectural principles.

This distinction is important for the implementation agent.

---

# 8. Preserve Application-State Ownership

While applying these changes, do not accidentally move application state into Chatter.

The following remain example-client concerns by default:

```text
unread state
drafts
local search
conversation sorting
selected conversation
opened thread
optimistic UI
observed-history persistence
local pending UI state
```

A draft retained while an account reconnects is application state.

It is **not** the same as a Chatter-managed outbound queue.

---

# 9. Preserve Semantic-Fidelity Principle

Add or reinforce this design rule where appropriate:

> The example client must not silently transform an unsupported user operation into a semantically different provider operation.

Examples:

Do not silently:

```text
reply → normal send
```

Do not silently:

```text
one message with N attachments → N separate messages
```

Do not silently:

```text
thread reply → ordinary conversation message
```

When a provider cannot represent the requested operation, the client should:

1. explain the limitation;
2. prevent the unsupported send; or
3. explicitly offer an alternative action that the user chooses.

This rule should align UI behavior with Chatter's public API semantics.

---

# 10. Review the Lifecycle Table

Update any lifecycle/status tables and diagrams so they consistently represent per-account state.

Suggested conceptual behavior:

| Account state | Read existing local messages | Send | Compose draft | Expected UI |
|---|---:|---:|---:|---|
| starting | yes | no | yes | account starting indicator |
| connected | yes | yes | yes | normal |
| reconnecting | yes | no | yes | reconnect indicator |
| degraded | yes | depends on resolved capability/state | yes | explain limitation |
| failed | yes | no | yes | account failure state |
| stopped | yes | no | yes | stopped/offline state |

This table describes UI behavior, not a required Chatter enum.

Do not introduce automatic outbound queueing.

---

# 11. Review Attachment Composition UX

Ensure the attachment composer uses capability descriptors before send.

Examples:

```text
maximum file size
allowed MIME types
maximum number of attachments
caption support
provider grouping limitations
```

Whenever possible, prevent invalid composition before invoking Chatter.

If a provider limitation only becomes known at send time, present the normalized error and preserve the user's composition where practical.

If an explicit alternative such as separate sends is offered, require user confirmation.

---

# 12. Review Reply UX

Update reply-target behavior to distinguish application knowledge from provider truth.

Possible states:

```text
target loaded locally
target not loaded locally
lookup in progress
target found
target unavailable according to provider lookup
provider has no lookup capability
```

Do not display:

```text
deleted
```

unless Chatter/provider semantics actually establish that fact.

Prefer neutral language when the reason is unknown.

---

# 13. Review Error UX

Ensure the design now assumes:

```text
normalized Chatter error category
+
optional normalized recovery metadata
+
optional diagnostics/raw cause
```

User-facing UI should use the normalized category/metadata.

Developer diagnostics may expose deeper provider information.

Examples:

### Rate limit

Normal UI:

```text
Temporarily unavailable. Try again shortly.
```

If normalized retry timing exists, the UI may present/use it.

### Provider unavailable

Normal UI:

```text
This account is temporarily unavailable.
```

Diagnostics may show provider-specific details.

Do not require the browser UI to parse provider SDK errors.

---

# 14. Review Status Rendering

Ensure provider status rendering is defined through provider-specific structured semantics/extensions.

For WhatsApp, examples may include:

```text
sent
delivered
read
failed
```

The shared message component may render a normalized presentation supplied through a provider extension.

Do not imply that every provider must expose the same status model.

---

# 15. Update Architecture Compatibility Review

Revise the existing Architecture Compatibility Review table to reflect these corrections.

Pay particular attention to:

```text
Lifecycle
Composer
Attachments
Replies
Message status
Error handling
History/message lookup
```

For each issue, classify it as one of:

```text
design-only
example-client application concern
Chatter public API requirement
provider-specific capability
provider limitation
```

---

# 16. Update Potential Chatter API Gaps

Review the current G1–G9 list.

Required changes:

## G7

Rename/reframe to something equivalent to:

```text
Normalized error metadata
```

rather than missing normalized error taxonomy.

## G8

Reframe around:

```text
optional message lookup/history semantics
```

rather than adding availability state to every message reference.

For every gap, continue providing:

```text
affected UX
why current model is insufficient
required capability/abstraction
blocking status
priority
```

Do not invent final TypeScript APIs unless they are already approved elsewhere.

---

# 17. Update Acceptance Criteria

Add/adjust acceptance criteria so the following are testable:

- reconnecting accounts do not automatically queue outbound messages;
- drafts remain recoverable while send is unavailable;
- unsupported multi-attachment grouping is never silently converted into separate messages;
- an explicitly offered semantic fallback requires user action;
- reply-target UI does not claim deletion when only local absence is known;
- normalized error metadata can drive retry/recovery UI where available;
- ordered provider status models do not visually regress due to out-of-order events;
- no global status ordering is assumed across all providers;
- healthy accounts remain usable while another account fails/reconnects.

---

# 18. Required Change Log

Produce:

# v1.2 → v1.2.1 Changes

Separate the changes into:

```text
Architecture corrections
Interaction corrections
API-gap corrections
Acceptance-criteria corrections
Visual changes
```

Expected visual changes should be minimal.

If no meaningful visual redesign was required, explicitly state:

```text
No visual redesign was required.
```

---

# 19. Final Deliverable

Produce:

```text
Chatter Client Design Spec v1.2.1
```

Use the existing v1.2 deliverable as the source of truth and apply only the corrections described here.

Do not generate production frontend code.

Do not re-open unrelated product decisions.

Do not bypass Chatter.

Do not redesign unaffected screens.

The expected result is a specification that is ready to be frozen as the implementation design unless implementation later reveals a genuine conflict.
