# Chatter Client Design Spec v1.2.1 — Frozen

This package is the frozen implementation design after the final architecture-alignment corrections.

Final editorial corrections applied:

1. Historical v1.2 references to G7/G8 are explicitly marked as superseded by the v1.2.1 definitions.
2. G6 lifecycle data no longer owns `canSend`; send availability is derived from account health plus contextual `message.send` capability resolution.
3. Search is local to the example-client application store by default, with provider-native search treated as an optional explicit capability.

No visual redesign was made. `Chatter Client Screens v1.2.dc.html` remains unchanged.
